<?php
declare(strict_types=1);

session_set_cookie_params([
    'httponly' => true,
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'samesite' => 'Lax',
]);
session_start();
require_once __DIR__ . '/db.php';

header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? '*'));
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$action = $_GET['action'] ?? '';
$body = json_input();

try {
    $pdo = db();

    if ($action === 'oauth/start' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $provider = $_GET['provider'] ?? '';
        $configFile = __DIR__ . '/oauth_config.php';
        if (!in_array($provider, ['google', 'github'], true) || !file_exists($configFile)) {
            json_response(['error' => 'OAuth provider is not configured.'], 503);
        }
        $oauth = require $configFile;
        if (empty($oauth[$provider]['client_id']) || empty($oauth[$provider]['client_secret'])) {
            json_response(['error' => 'OAuth provider is not configured.'], 503);
        }
        $state = bin2hex(random_bytes(24));
        $_SESSION['oauth_state'] = $state;
        $_SESSION['oauth_provider'] = $provider;
        $returnTo = (string)($_GET['return_to'] ?? '/dashboard');
        $_SESSION['oauth_return_to'] = (str_starts_with($returnTo, '/') && !str_starts_with($returnTo, '//')) ? $returnTo : '/dashboard';
        $callback = (($_SERVER['HTTPS'] ?? '') !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/api/index.php?action=oauth/callback&provider=' . rawurlencode($provider);
        if ($provider === 'google') {
            $url = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
                'client_id' => $oauth['google']['client_id'],
                'redirect_uri' => $callback,
                'response_type' => 'code',
                'scope' => 'openid email profile',
                'state' => $state,
                'access_type' => 'online',
                'prompt' => 'select_account',
            ]);
        } else {
            $url = 'https://github.com/login/oauth/authorize?' . http_build_query([
                'client_id' => $oauth['github']['client_id'],
                'redirect_uri' => $callback,
                'scope' => 'read:user user:email',
                'state' => $state,
            ]);
        }
        header('Location: ' . $url, true, 302);
        exit;
    }

    if ($action === 'oauth/callback' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $provider = $_GET['provider'] ?? '';
        $state = (string)($_GET['state'] ?? '');
        $expectedState = (string)($_SESSION['oauth_state'] ?? '');
        if (!hash_equals($expectedState, $state) || ($_SESSION['oauth_provider'] ?? '') !== $provider) {
            json_response(['error' => 'Invalid OAuth state. Please try again.'], 400);
        }
        unset($_SESSION['oauth_state'], $_SESSION['oauth_provider']);
        $returnTo = $_SESSION['oauth_return_to'] ?? '/dashboard';
        unset($_SESSION['oauth_return_to']);
        if (!empty($_GET['error'])) {
            header('Location: ' . $returnTo . '?oauth_error=' . rawurlencode((string)$_GET['error']), true, 302);
            exit;
        }
        $code = (string)($_GET['code'] ?? '');
        $configFile = __DIR__ . '/oauth_config.php';
        if (!$code || !file_exists($configFile)) json_response(['error' => 'OAuth callback is not configured.'], 503);
        $oauth = require $configFile;
        $callback = (($_SERVER['HTTPS'] ?? '') !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/api/index.php?action=oauth/callback&provider=' . rawurlencode($provider);
        if ($provider === 'google') {
            $token = oauth_post('https://oauth2.googleapis.com/token', [
                'code' => $code, 'client_id' => $oauth['google']['client_id'], 'client_secret' => $oauth['google']['client_secret'],
                'redirect_uri' => $callback, 'grant_type' => 'authorization_code',
            ]);
            $identity = oauth_get('https://openidconnect.googleapis.com/v1/userinfo', $token['access_token'] ?? '');
            $subject = $identity['sub'] ?? '';
            $email = strtolower((string)($identity['email'] ?? ''));
            $name = (string)($identity['name'] ?? '');
            $avatar = $identity['picture'] ?? null;
        } elseif ($provider === 'github') {
            $token = oauth_post('https://github.com/login/oauth/access_token', [
                'code' => $code, 'client_id' => $oauth['github']['client_id'], 'client_secret' => $oauth['github']['client_secret'],
                'redirect_uri' => $callback,
            ], ['Accept: application/json']);
            $accessToken = $token['access_token'] ?? '';
            $identity = oauth_get('https://api.github.com/user', $accessToken);
            $emails = oauth_get('https://api.github.com/user/emails', $accessToken);
            $email = '';
            foreach (is_array($emails) ? $emails : [] as $item) {
                if (!empty($item['email']) && !empty($item['verified']) && (($item['primary'] ?? false) || !$email)) {
                    $email = strtolower((string)$item['email']);
                    if (!empty($item['primary'])) break;
                }
            }
            $subject = (string)($identity['id'] ?? '');
            $name = (string)($identity['name'] ?: ($identity['login'] ?? ''));
            $avatar = $identity['avatar_url'] ?? null;
        } else {
            json_response(['error' => 'Unsupported OAuth provider.'], 400);
        }
        if (!$subject || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_response(['error' => 'The provider did not return a verified email address.'], 422);
        }
        $stmt = $pdo->prepare('SELECT * FROM users WHERE (oauth_provider = ? AND oauth_subject = ?) OR email = ? LIMIT 1');
        $stmt->execute([$provider, $subject, $email]);
        $user = $stmt->fetch();
        if ($user) {
            $stmt = $pdo->prepare('UPDATE users SET email=?, full_name=?, avatar_url=?, oauth_provider=?, oauth_subject=?, updated_at=NOW() WHERE id=?');
            $stmt->execute([$email, $name, $avatar, $provider, $subject, $user['id']]);
            $user['email'] = $email; $user['full_name'] = $name; $user['avatar_url'] = $avatar;
        } else {
            $id = uuid();
            $stmt = $pdo->prepare('INSERT INTO users (id,email,password_hash,full_name,avatar_url,oauth_provider,oauth_subject) VALUES (?,?,?,?,?,?,?)');
            $stmt->execute([$id, $email, password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT), $name, $avatar, $provider, $subject]);
            $stmt = $pdo->prepare('SELECT * FROM users WHERE id=?');
            $stmt->execute([$id]);
            $user = $stmt->fetch();
        }
        $_SESSION['user_id'] = $user['id'];
        header('Location: ' . $returnTo, true, 302);
        exit;
    }

    if ($action === 'auth/signup' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = strtolower(trim((string)($body['email'] ?? '')));
        $password = (string)($body['password'] ?? '');
        $name = trim((string)($body['full_name'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
            json_response(['error' => 'Enter a valid email and a password of at least 6 characters.'], 422);
        }
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) json_response(['error' => 'An account with this email already exists.'], 409);
        $id = uuid();
        $stmt = $pdo->prepare('INSERT INTO users (id,email,password_hash,full_name) VALUES (?,?,?,?)');
        $stmt->execute([$id, $email, password_hash($password, PASSWORD_DEFAULT), $name]);
        $_SESSION['user_id'] = $id;
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$id]);
        $createdUser = $stmt->fetch();
        json_response(['user' => public_user($createdUser), 'session' => ['user' => public_user($createdUser)]]);
    }

    if ($action === 'auth/login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = strtolower(trim((string)($body['email'] ?? '')));
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if (!$user || !password_verify((string)($body['password'] ?? ''), $user['password_hash'])) {
            json_response(['error' => 'Invalid email or password.'], 401);
        }
        $_SESSION['user_id'] = $user['id'];
        $safe = public_user($user);
        json_response(['user' => $safe, 'session' => ['user' => $safe]]);
    }

    if ($action === 'auth/session' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        if (empty($_SESSION['user_id'])) json_response(['session' => null]);
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if (!$user) { session_destroy(); json_response(['session' => null]); }
        $safe = public_user($user);
        json_response(['session' => ['user' => $safe]]);
    }

    if ($action === 'auth/logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $_SESSION = [];
        session_destroy();
        json_response(['ok' => true]);
    }

    $userId = current_user_id();

    if (str_starts_with($action, 'data/') && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $table = substr($action, 5);
        if ($table === 'profiles') {
            $stmt = $pdo->prepare('SELECT id,email,full_name,subscription_tier,subscription_status,tokens_used,token_limit FROM users WHERE id = ?');
            $stmt->execute([$userId]);
            json_response(['data' => [$stmt->fetch()]]);
        }
        if ($table === 'prompt_history') {
            $module = trim((string)($_GET['module_type'] ?? ''));
            $sql = 'SELECT id,user_id,module_type,input_data,output_text,language,tokens_estimated,created_at FROM prompt_history WHERE user_id = ?';
            $params = [$userId];
            if ($module !== '' && $module !== 'all') { $sql .= ' AND module_type = ?'; $params[] = $module; }
            $sql .= ' ORDER BY created_at DESC';
            if (!empty($_GET['limit'])) { $sql .= ' LIMIT ' . max(1, min(100, (int)$_GET['limit'])); }
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$row) $row['input_data'] = $row['input_data'] ? json_decode($row['input_data'], true) : null;
            json_response(['data' => $rows]);
        }
        json_response(['error' => 'Unknown data table'], 404);
    }
    if (str_starts_with($action, 'data/') && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
        $table = substr($action, 5);
        if ($table === 'profiles') {
            $stmt = $pdo->prepare('UPDATE users SET full_name = ? WHERE id = ?');
            $stmt->execute([trim((string)($body['full_name'] ?? '')), $userId]);
            json_response(['data' => ['ok' => true]]);
        }
        json_response(['error' => 'Unsupported update'], 400);
    }
    if (str_starts_with($action, 'data/') && $_SERVER['REQUEST_METHOD'] === 'POST') {
        if (substr($action, 5) === 'prompt_history') {
            $stmt = $pdo->prepare('INSERT INTO prompt_history (id,user_id,module_type,input_data,output_text,language,tokens_estimated) VALUES (?,?,?,?,?,?,?)');
            $stmt->execute([uuid(), $userId, $body['module_type'] ?? '', json_encode($body['input_data'] ?? null), $body['output_text'] ?? '', $body['language'] ?? null, (int)($body['tokens_estimated'] ?? 0)]);
            json_response(['data' => ['ok' => true]]);
        }
        json_response(['error' => 'Unsupported insert'], 400);
    }
    if (str_starts_with($action, 'data/') && $_SERVER['REQUEST_METHOD'] === 'DELETE') {
        if (substr($action, 5) === 'prompt_history') {
            $stmt = $pdo->prepare('DELETE FROM prompt_history WHERE id = ? AND user_id = ?');
            $stmt->execute([(string)($_GET['id'] ?? ''), $userId]);
            json_response(['data' => ['ok' => true]]);
        }
        json_response(['error' => 'Unsupported delete'], 400);
    }

    if ($action === 'profile' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $pdo->prepare('SELECT id,email,full_name,subscription_tier,subscription_status,tokens_used,token_limit FROM users WHERE id = ?');
        $stmt->execute([$userId]);
        json_response(['data' => $stmt->fetch()]);
    }
    if ($action === 'profile' && $_SERVER['REQUEST_METHOD'] === 'PATCH') {
        $stmt = $pdo->prepare('UPDATE users SET full_name = ? WHERE id = ?');
        $stmt->execute([trim((string)($body['full_name'] ?? '')), $userId]);
        json_response(['data' => ['ok' => true]]);
    }
    if ($action === 'usage' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $amount = max(0, (int)($body['amount'] ?? 0));
        $pdo->beginTransaction();
        $stmt = $pdo->prepare('SELECT tokens_used, token_limit FROM users WHERE id = ? FOR UPDATE');
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        if (!$user || ((int)$user['tokens_used'] + $amount) > (int)$user['token_limit']) {
            $pdo->rollBack();
            json_response(['data' => ['success' => false]]);
        }
        $stmt = $pdo->prepare('UPDATE users SET tokens_used = tokens_used + ? WHERE id = ?');
        $stmt->execute([$amount, $userId]);
        $stmt = $pdo->prepare('INSERT INTO usage_logs (id,user_id,action,token_count) VALUES (?,?,?,?)');
        $stmt->execute([uuid(), $userId, 'generation', $amount]);
        $pdo->commit();
        json_response(['data' => ['success' => true]]);
    }
    if ($action === 'history' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $module = trim((string)($_GET['module'] ?? ''));
        $sql = 'SELECT id,user_id,module_type,input_data,output_text,language,tokens_estimated,created_at FROM prompt_history WHERE user_id = ?';
        $params = [$userId];
        if ($module !== '' && $module !== 'all') { $sql .= ' AND module_type = ?'; $params[] = $module; }
        $sql .= ' ORDER BY created_at DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$row) $row['input_data'] = $row['input_data'] ? json_decode($row['input_data'], true) : null;
        json_response(['data' => $rows]);
    }
    if ($action === 'history' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $stmt = $pdo->prepare('INSERT INTO prompt_history (id,user_id,module_type,input_data,output_text,language,tokens_estimated) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([uuid(), $userId, $body['module_type'] ?? '', json_encode($body['input_data'] ?? null), $body['output_text'] ?? '', $body['language'] ?? null, (int)($body['tokens_estimated'] ?? 0)]);
        json_response(['data' => ['ok' => true]]);
    }
    if ($action === 'history' && $_SERVER['REQUEST_METHOD'] === 'DELETE') {
        $stmt = $pdo->prepare('DELETE FROM prompt_history WHERE id = ? AND user_id = ?');
        $stmt->execute([(string)($_GET['id'] ?? ''), $userId]);
        json_response(['data' => ['ok' => true]]);
    }

    json_response(['error' => 'Unknown API action'], 404);
} catch (Throwable $e) {
    error_log('LogSgen API error: ' . $e->getMessage());
    json_response(['error' => 'Server error. Check the cPanel PHP error log.'], 500);
}

function oauth_post(string $url, array $fields, array $headers = []): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($fields),
        CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'], $headers),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = json_decode((string)$response, true);
    if ($status < 200 || $status >= 300 || !is_array($data) || !empty($data['error'])) {
        json_response(['error' => 'OAuth provider rejected the login.'], 502);
    }
    return $data;
}

function oauth_get(string $url, string $accessToken): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $accessToken, 'Accept: application/json', 'User-Agent: LogSgen-AI'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = json_decode((string)$response, true);
    if ($status < 200 || $status >= 300 || !is_array($data)) {
        json_response(['error' => 'Could not read the OAuth provider profile.'], 502);
    }
    return $data;
}