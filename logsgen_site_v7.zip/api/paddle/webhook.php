<?php
declare(strict_types=1);

// Set this URL in Paddle:
// https://logsgen.com/api/paddle/webhook.php
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json');
$rawBody = file_get_contents('php://input');
$signatureHeader = $_SERVER['HTTP_PADDLE_SIGNATURE'] ?? '';
$webhookSecret = getenv('PADDLE_WEBHOOK_SECRET') ?: '';

/**
 * Paddle signs the timestamp followed by the exact raw request body.
 *
 * The header may contain more than one h1 value while Paddle rotates
 * endpoint secrets, so accept the request when any supplied signature
 * matches the configured secret.
 */
function is_valid_paddle_signature(string $rawBody, string $signatureHeader, string $webhookSecret): bool {
    if ($rawBody === '' || $signatureHeader === '' || $webhookSecret === '') {
        return false;
    }

    $timestamp = '';
    $signatures = [];
    foreach (explode(';', $signatureHeader) as $part) {
        [$key, $value] = array_pad(explode('=', $part, 2), 2, '');
        if ($key === 'ts' && $value !== '') {
            $timestamp = $value;
        } elseif ($key === 'h1' && $value !== '') {
            $signatures[] = $value;
        }
    }

    if ($timestamp === '' || $signatures === []) {
        return false;
    }

    $expectedSignature = hash_hmac('sha256', $timestamp . ':' . $rawBody, $webhookSecret);
    foreach ($signatures as $signature) {
        if (hash_equals($expectedSignature, $signature)) {
            return true;
        }
    }

    return false;
}

if (!is_valid_paddle_signature($rawBody, $signatureHeader, $webhookSecret)) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid webhook signature']);
    exit;
}

$payload = json_decode($rawBody, true);
$event = $payload['event_type'] ?? '';
$data = $payload['data'] ?? [];
$customerId = $data['customer_id'] ?? '';

if (!$event || !$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid webhook payload']);
    exit;
}

try {
    $pdo = db();
    if (in_array($event, ['subscription.created', 'subscription.updated'], true) && $customerId) {
        $priceId = $data['items'][0]['price_id'] ?? '';
        $starterId = getenv('PADDLE_STARTER_PRICE_ID') ?: '';
        $proId = getenv('PADDLE_PRO_PRICE_ID') ?: '';
        $scaleId = getenv('PADDLE_SCALE_PRICE_ID') ?: '';
        $tier = $priceId === $scaleId ? 'scale' : ($priceId === $proId ? 'pro' : 'starter');
        $limits = ['starter' => 50000, 'pro' => 250000, 'scale' => 999999999];
        $stmt = $pdo->prepare('UPDATE users SET subscription_tier=?, subscription_status=?, paddle_customer_id=?, paddle_subscription_id=?, token_limit=?, updated_at=NOW() WHERE paddle_customer_id=? OR (email = ? AND (paddle_customer_id IS NULL OR paddle_customer_id = ""))');
        $email = $data['customer']['email'] ?? $data['customer_email'] ?? '';
        $stmt->execute([$tier, $data['status'] ?? 'active', $customerId, $data['id'] ?? null, $limits[$tier], $customerId, $email]);
    } elseif ($event === 'subscription.canceled' && $customerId) {
        $stmt = $pdo->prepare("UPDATE users SET subscription_status='canceled', subscription_tier='free', updated_at=NOW() WHERE paddle_customer_id=?");
        $stmt->execute([$customerId]);
    }
    echo json_encode(['ok' => true]);
} catch (Throwable $e) {
    error_log('Paddle webhook error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Webhook processing failed']);
}