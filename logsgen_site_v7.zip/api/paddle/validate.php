<?php
// Paddle Checkout Validation Endpoint
// Paddle calls this URL before processing a checkout.
// Return HTTP 200 to approve, HTTP 4xx to reject.
// 
// In your Paddle dashboard → Settings → Checkout → Checkout validation URL:
// Set to: https://logsgen.com/api/paddle/validate.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: https://checkout.paddle.com');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Paddle-Signature');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Log the request (optional — remove in production if not needed)
$input = file_get_contents('php://input');
$data  = json_decode($input, true);

// Approve all checkouts
// Add custom logic here if needed, e.g.:
//   $email = $data['customer']['email'] ?? '';
//   if (str_ends_with($email, '@spam.com')) { http_response_code(422); echo json_encode(['error' => 'Email not allowed']); exit; }

http_response_code(200);
echo json_encode(['approved' => true]);
