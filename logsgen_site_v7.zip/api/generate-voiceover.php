<?php
// LogSgen AI — authenticated text-to-speech (voiceover) proxy for cPanel.
// Uses the same POLLINATIONS_API_KEY already configured in api_config.php.
header('X-Content-Type-Options: nosniff');

function voice_error(string $message, int $status): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $message]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') voice_error('Only POST method allowed.', 405);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['user_id'])) voice_error('Please sign in before generating a voiceover.', 401);

$input = json_decode(file_get_contents('php://input'), true);
$text  = trim((string)($input['text'] ?? ''));
$voice = strtolower(trim((string)($input['voice'] ?? 'nova')));

if ($text === '') voice_error('Please enter the text you want to turn into a voiceover.', 400);
if (function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') > 2000 : strlen($text) > 6000) {
    voice_error('Text is too long. Please keep it under 2,000 characters.', 413);
}

$allowedVoices = ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'];
if (!in_array($voice, $allowedVoices, true)) $voice = 'nova';

$configFile = __DIR__ . '/api_config.php';
if (!file_exists($configFile)) voice_error('Server is missing api_config.php.', 500);
require_once $configFile;
if (empty($POLLINATIONS_API_KEY) || $POLLINATIONS_API_KEY === 'REPLACE_WITH_YOUR_POLLINATIONS_SECRET_KEY') {
    voice_error('Add a valid POLLINATIONS_API_KEY to api_config.php.', 500);
}

$payload = json_encode([
    'model' => 'tts-1',
    'input' => $text,
    'voice' => $voice,
]);

$ch = curl_init('https://gen.pollinations.ai/v1/audio/speech');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $POLLINATIONS_API_KEY,
        'Content-Type: application/json',
        'Accept: audio/mpeg',
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 120,
    CURLOPT_SSL_VERIFYPEER => true,
]);
$response    = curl_exec($ch);
$httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: '';
$curlError   = curl_error($ch);
curl_close($ch);

if ($curlError) voice_error('Could not connect to the voice service. Check cURL and outbound HTTPS.', 502);
if ($httpCode < 200 || $httpCode >= 300) {
    $data = json_decode((string)$response, true);
    $message = $data['error']['message'] ?? ($data['error'] ?? 'The voice service rejected the request.');
    if (!is_string($message)) $message = 'The voice service rejected the request.';
    voice_error($message, $httpCode >= 400 && $httpCode < 500 ? $httpCode : 502);
}
if (stripos($contentType, 'audio/') !== 0) voice_error('The voice service returned an unexpected response.', 502);

header('Content-Type: audio/mpeg');
header('Cache-Control: no-store');
echo $response;
