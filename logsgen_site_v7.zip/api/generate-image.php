<?php
// LogSgen AI — authenticated Pollinations image proxy for cPanel.
header('X-Content-Type-Options: nosniff');

function image_error(string $message, int $status): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $message]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') image_error('Only GET method allowed.', 405);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['user_id'])) image_error('Please sign in before generating images.', 401);

$prompt = trim((string)($_GET['prompt'] ?? ''));
if ($prompt === '') image_error('prompt is required.', 400);
if (strlen($prompt) > 4000) image_error('prompt is too long.', 413);

$configFile = __DIR__ . '/api_config.php';
if (!file_exists($configFile)) image_error('Create api_config.php with a valid POLLINATIONS_API_KEY.', 500);
require_once $configFile;
if (empty($POLLINATIONS_API_KEY) || $POLLINATIONS_API_KEY === 'REPLACE_WITH_YOUR_POLLINATIONS_SECRET_KEY') {
    image_error('Add a valid POLLINATIONS_API_KEY in api_config.php.', 500);
}

$dimension = static function ($value, int $fallback): int {
    $parsed = filter_var($value, FILTER_VALIDATE_INT);
    return $parsed === false ? $fallback : max(256, min(1536, $parsed));
};
$width = $dimension($_GET['width'] ?? null, 1024);
$height = $dimension($_GET['height'] ?? null, 576);
$seed = max(0, min(999999, (int)($_GET['seed'] ?? 0)));
$url = 'https://gen.pollinations.ai/image/' . rawurlencode($prompt) . '?' . http_build_query([
    'width' => $width,
    'height' => $height,
    'seed' => $seed,
    'model' => 'flux',
]);

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $POLLINATIONS_API_KEY,
        'Accept: image/*',
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 120,
    CURLOPT_SSL_VERIFYPEER => true,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: '';
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) image_error('Could not connect to Pollinations image generation. Check cURL and outbound HTTPS.', 502);
if ($httpCode < 200 || $httpCode >= 300) {
    $data = json_decode((string)$response, true);
    $message = $data['error']['message'] ?? 'Pollinations rejected the image request. Check the key and Pollen balance.';
    image_error($message, $httpCode >= 400 && $httpCode < 500 ? $httpCode : 502);
}
if (strpos($contentType, 'image/') !== 0) image_error('Pollinations returned a non-image response.', 502);

header('Content-Type: ' . $contentType);
header('Cache-Control: private, max-age=300');
echo $response;