<?php
// LogSgen AI — cPanel endpoint for extracting image scenes from a script.
header('Content-Type: application/json; charset=utf-8');

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Please sign in before generating content.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Only POST method allowed']);
    exit;
}

$configFile = __DIR__ . '/api_config.php';
if (!file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Create public_html/api/api_config.php with a valid POLLINATIONS_API_KEY']);
    exit;
}
require_once $configFile;
if (empty($POLLINATIONS_API_KEY) || $POLLINATIONS_API_KEY === 'REPLACE_WITH_YOUR_POLLINATIONS_SECRET_KEY') {
    http_response_code(500);
    echo json_encode(['error' => 'Add a valid POLLINATIONS_API_KEY in public_html/api/api_config.php']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$script = trim((string)($input['script'] ?? ''));
$style = trim((string)($input['style'] ?? 'cinematic'));
$count = max(2, min(8, (int)($input['count'] ?? 4)));
if ($script === '') {
    http_response_code(400);
    echo json_encode(['error' => 'script is required']);
    exit;
}

$systemPrompt = "You are an expert visual storyteller and prompt engineer. Extract {$count} vivid, distinct image-generation prompts from the supplied script. Optimize for {$style}. Each prompt should be 15–30 words, descriptive of subject, composition, lighting, and mood. Return only one prompt per line, with no numbering or explanations.";
$payload = json_encode([
    'model' => 'openai/gpt-5.4-nano',
    'messages' => [
        ['role' => 'system', 'content' => $systemPrompt],
        ['role' => 'user', 'content' => "Extract {$count} visual scenes from this script:\n\n{$script}"],
    ],
    'temperature' => 0.7,
    'max_tokens' => 1200,
]);

$ch = curl_init('https://gen.pollinations.ai/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $POLLINATIONS_API_KEY,
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 60,
    CURLOPT_SSL_VERIFYPEER => true,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    http_response_code(502);
    echo json_encode(['error' => 'Could not connect to the AI service. Check that cURL and outbound HTTPS are enabled on your hosting account.']);
    exit;
}
$data = json_decode((string)$response, true);
if ($httpCode < 200 || $httpCode >= 300) {
    http_response_code($httpCode >= 400 && $httpCode < 500 ? $httpCode : 502);
    echo json_encode(['error' => $data['error']['message'] ?? 'Pollinations rejected the request. Check the key and Pollen balance.']);
    exit;
}

$text = $data['choices'][0]['message']['content'] ?? '';
$scenes = array_values(array_slice(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $text)), fn($line) => strlen($line) > 10), 0, $count));
echo json_encode(['scenes' => $scenes], JSON_UNESCAPED_UNICODE);