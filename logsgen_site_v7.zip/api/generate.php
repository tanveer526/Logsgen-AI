<?php
// LogSgen AI — Pollinations text-generation proxy for cPanel

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Please sign in before generating content.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Only POST method allowed']);
    http_response_code(405);
    exit;
}

// ── Read API key from config file ──────────────────────────────
$configFile = __DIR__ . '/api_config.php';
if (!file_exists($configFile)) {
    echo json_encode(['error' => 'Missing api_config.php — configure POLLINATIONS_API_KEY on the server.']);
    http_response_code(500);
    exit;
}
require_once $configFile;

if (empty($POLLINATIONS_API_KEY) || $POLLINATIONS_API_KEY === 'REPLACE_WITH_YOUR_POLLINATIONS_SECRET_KEY') {
    echo json_encode(['error' => 'Add a valid POLLINATIONS_API_KEY in public_html/api/api_config.php']);
    http_response_code(500);
    exit;
}

// ── Parse request body ─────────────────────────────────────────
$input    = json_decode(file_get_contents('php://input'), true);
$prompt   = $input['prompt']   ?? '';
$language = $input['language'] ?? 'English';
$tone     = $input['tone']     ?? 'professional';

if (empty($prompt)) {
    echo json_encode(['error' => 'prompt is required']);
    http_response_code(400);
    exit;
}

// ── Build Pollinations request (OpenAI-compatible format) ──────
$systemPrompt = "You are LogSgen AI, a world-class creator OS. Output must be in $language. Tone: $tone. If the language is Arabic or Urdu, ensure the text is culturally relevant. Provide structured, high-impact content for creators.";

$requestBody = json_encode([
    'model'       => 'openai/gpt-5.4-nano',
    'messages'    => [
        ['role' => 'system', 'content' => $systemPrompt],
        ['role' => 'user',   'content' => $prompt],
    ],
    'temperature' => 0.7,
    'max_tokens'  => 2048,
]);

$apiUrl = 'https://gen.pollinations.ai/v1/chat/completions';

// ── Call Pollinations API ──────────────────────────────────────
$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $requestBody,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $POLLINATIONS_API_KEY,
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 60,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response  = curl_exec($ch);
$httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    echo json_encode(['error' => 'Could not connect to Pollinations. Check cURL and outbound HTTPS on the hosting account.']);
    http_response_code(502);
    exit;
}

$data = json_decode($response, true);

if ($httpCode !== 200) {
    $message = $data['error']['message'] ?? 'Pollinations rejected the request. Check the key and Pollen balance.';
    echo json_encode(['error' => $message]);
    http_response_code($httpCode);
    exit;
}

$text = $data['choices'][0]['message']['content'] ?? '';
echo json_encode(['text' => $text]);
