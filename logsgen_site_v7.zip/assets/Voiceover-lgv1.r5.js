import{r as a,h as T,j as e,B as d,e as k,f as F}from"./index-DuxHYD25.r5.js";import{C as g}from"./UI-D5oaZXl-.r5.js";
const Mic=F("Mic",[["path",{d:"M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z",key:"a"}],["path",{d:"M19 10v2a7 7 0 0 1-14 0v-2",key:"b"}],["line",{x1:"12",x2:"12",y1:"19",y2:"22",key:"c"}]]),Down=F("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"a"}],["polyline",{points:"7 10 12 15 17 10",key:"b"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"c"}]]),Vol=F("Volume2",[["path",{d:"M11 5 6 9H2v6h4l5 4V5Z",key:"a"}],["path",{d:"M15.54 8.46a5 5 0 0 1 0 7.07",key:"b"}],["path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14",key:"c"}]]);
const VOICES=[["nova","Nova — bright"],["alloy","Alloy — neutral"],["echo","Echo — calm"],["fable","Fable — expressive"],["onyx","Onyx — deep"],["shimmer","Shimmer — soft"]],MAX=2e3,COST=30;
function VoiceoverPage(){
const[text,setText]=a.useState(""),[voice,setVoice]=a.useState("nova"),[loading,setLoading]=a.useState(!1),[audioUrl,setAudioUrl]=a.useState(""),[error,setError]=a.useState(null),{profile:p,profileError:pe,useTokens:ut}=T();
a.useEffect(()=>()=>{audioUrl&&URL.revokeObjectURL(audioUrl)},[audioUrl]);
const generate=async()=>{
const t=text.trim();if(!t)return;
if(!p){setError(pe||"Your account balance could not be loaded. Refresh the page and try again.");return}
if(p.token_limit-p.tokens_used<COST){setError("Not enough tokens. Please upgrade your plan.");return}
setLoading(!0);setError(null);
try{
const r=await fetch("/api/generate-voiceover.php",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:t,voice:voice})});
const ct=r.headers.get("content-type")||"";
if(!r.ok||!ct.startsWith("audio/")){let m="Could not generate the voiceover. Please try again.";try{const j=await r.json();m=j.error||m}catch(_){}throw new Error(m)}
const blob=await r.blob();
if(!(await ut(COST))){setError("Could not update your token balance. Please refresh and try again.");return}
setAudioUrl(URL.createObjectURL(blob))
}catch(err){setError(err&&err.message?err.message:"Error generating the voiceover.")}finally{setLoading(!1)}
};
const download=()=>{if(!audioUrl)return;const l=document.createElement("a");l.href=audioUrl;l.download="logsgen-voiceover.mp3";document.body.appendChild(l);l.click();l.remove()};
return e.jsxs("div",{className:"space-y-8",children:[
e.jsxs("div",{children:[e.jsxs("h1",{className:"text-3xl font-bold mb-2 flex items-center gap-3",children:[e.jsx(Mic,{className:"h-8 w-8 text-emerald-500"})," Voiceover Generator"]}),e.jsx("p",{className:"text-zinc-400",children:"Turn your script into a natural-sounding voiceover you can download."})]}),
e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-8",children:[
e.jsxs(g,{className:"flex flex-col p-0 overflow-hidden",children:[
e.jsxs("div",{className:"px-6 py-4 border-b border-zinc-800 bg-zinc-900/50 flex items-center justify-between",children:[e.jsx("span",{className:"text-sm font-medium text-zinc-400",children:"Script"}),e.jsx(d,{variant:"ghost",size:"sm",onClick:()=>setText(""),children:"Clear"})]}),
e.jsx("textarea",{className:"flex-1 min-h-[400px] bg-transparent p-6 text-zinc-100 focus:outline-none resize-none",placeholder:"Paste the script you want to hear...",maxLength:MAX,value:text,onChange:l=>setText(l.target.value)}),
e.jsxs("div",{className:"p-4 border-t border-zinc-800 bg-zinc-900/50 flex flex-wrap items-center justify-between gap-4",children:[
e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-xs text-zinc-500",children:"Voice:"}),e.jsx("select",{className:"bg-zinc-800 border-none rounded px-2 py-1 text-xs text-zinc-300 focus:ring-1 focus:ring-emerald-500",value:voice,onChange:l=>setVoice(l.target.value),children:VOICES.map(([v,n])=>e.jsx("option",{value:v,children:n},v))})]}),
e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("span",{className:"text-xs text-zinc-500",children:[text.length," / ",MAX]}),e.jsxs(d,{size:"sm",onClick:generate,isLoading:loading,disabled:!text.trim(),className:"gap-2",children:[e.jsx(Mic,{className:"h-4 w-4"})," Generate Voiceover"]})]})]}),
error&&e.jsx("div",{className:"px-4 pb-4",children:e.jsx("div",{className:"p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500 text-xs text-center",children:error})})]}),
e.jsxs(g,{className:"flex flex-col p-0 overflow-hidden",children:[
e.jsxs("div",{className:"px-6 py-4 border-b border-zinc-800 bg-zinc-900/50 flex items-center justify-between",children:[e.jsx("span",{className:"text-sm font-medium text-zinc-400",children:"Your voiceover"}),audioUrl&&e.jsxs(d,{variant:"outline",size:"sm",onClick:download,className:"gap-2",children:[e.jsx(Down,{className:"h-4 w-4"})," Download MP3"]})]}),
e.jsx("div",{className:"flex-1 p-6 flex flex-col items-center justify-center min-h-[400px]",children:audioUrl?e.jsxs("div",{className:"w-full space-y-4",children:[e.jsx("audio",{controls:!0,src:audioUrl,className:"w-full"}),e.jsx("p",{className:"text-xs text-zinc-500 text-center",children:"Listen first, then download. Generating again replaces this voiceover."})]}):e.jsxs("div",{className:"text-zinc-600 flex flex-col items-center space-y-4 text-center",children:[e.jsx(Vol,{className:"h-12 w-12 opacity-20"}),e.jsx("p",{children:"Your voiceover will appear here."})]})}),
e.jsx("div",{className:"px-6 py-3 border-t border-zinc-800 bg-zinc-900/50 text-xs text-zinc-500",children:"Uses "+COST+" tokens per voiceover. Works best in English. Urdu, Arabic and Spanish are supported, but quality varies, so always listen before you post."})]})
]})]})}
export{VoiceoverPage as default};
